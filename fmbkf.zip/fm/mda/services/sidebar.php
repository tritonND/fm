<nav id="sidebar" class="active">

    <button type="button" id="sidebarCollapse" class="btn btn-lg" style="background: #343752;">
        <i class="fa fa-bars" style="color:rgb(147, 168, 185) !important;"></i>
        <span class="sr-only">Toggle Menu</span>
    </button>


    <!-- <h1><a href="dash.html" class="logo">FM</a></h1> -->
    <ul class="list-unstyled components mb-5" >


        <li>
            <a href="#"><span class="fa fa-bullseye fas" ></span> </a>
        </li>

        <li class="active">
            <a href="#"><span class="fa fa-star fas" ></span> </a>
        </li>

        <li>
            <a href="#"><span class="fa fa-heart fas" ></span> </a>
        </li>


        <li>
            <a href="#"><span class="fa fa-bar-chart-o fas" ></span> </a>
        </li>

        <li>
            <a href="#"><span class="fa fa-map-marker fas" ></span> </a>
        </li>

        <li>
            <a href="#"><span class="fa fa-paper-plane-o fas" ></span> </a>
        </li>

        <li>
            <a href="#"><span class="fa fa-sun-o fas"></span> </a>
        </li>

        <li>
            <a href="#"><span class="fa fa-lock fas"></span> </a>

        </li>


    </ul>

    <div class="footer" >
        <p> Copyright &copy;<script>document.write(new Date().getFullYear());</script> Developed by Zena Concepts</p>
    </div>

</nav>


