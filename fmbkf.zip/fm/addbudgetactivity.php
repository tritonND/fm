<?php
session_start();
include "services/connect.php";

if(!isset($_SESSION["user"])){
    header( "Location: index");
}
else{

}

$organization = $_SESSION['organization'];
$ministry = $_SESSION['ministry'];
$sector = $_SESSION['sector'];
$states = $_SESSION['states'];

//$myqryx = "select accountname from fm_account_list where state = '$states' and
//  ministry = '$ministry' and sector = '$sector' and organization = '$organization'";
//$result3 = mysqli_query($conn, $myqryx);

$budgetid = $_GET['id'];

$myqry = "select budgetname from fm_budget where ID = '$budgetid'";
$result3 = mysqli_query($conn, $myqry);
$row =  mysqli_fetch_array($result3);


$myqry2 = "select funder from fm_funders where state = '$states' and 
  ministry = '$ministry' and sector = '$sector' and organization = '$organization' ";
$result2 = mysqli_query($conn, $myqry2);


$myqryeco = "select description from fm_account_code_list where accountname = 'economic' ";
$resulteco = mysqli_query($conn, $myqryeco);



$myqryadm = "select description from fm_account_code_list where accountname = 'administrative' ";
$resultadm = mysqli_query($conn, $myqryadm);


$myqryfunc = "select description from fm_account_code_list where accountname = 'functional' ";
$resultfunc = mysqli_query($conn, $myqryfunc);

$myqryfund = "select description from fm_account_code_list where accountname = 'fund' ";
$resultfund = mysqli_query($conn, $myqryfund);


$myqrypro = "select description from fm_account_code_list where accountname = 'program' ";
$resultpro = mysqli_query($conn, $myqrypro);


$myqrylga = "select lga from statelga where states = '$states'";
$resultlga = mysqli_query($conn, $myqrylga);

?>

<!doctype html>
<html lang="en">
<head>
    <title>Dashboard</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">

    <link rel="stylesheet" href="assets/fontawesome/css/all.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

    <link rel="stylesheet" href="assets/bootstrap/css/style.css">
    <link rel="stylesheet" href="assets/css/hyperform.min.css">
    <script src="assets/js/polyfill.min.js"></script>
    <script src="assets/js/hyperform.min.js"></script>

    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300&display=swap" rel="stylesheet">


    <script src="assets/js/sweetalert2.all.min.js"></script>
    <link href="assets/css/sweetalert2.min.css" rel="stylesheet">
    <link href="assets/css/bootstrap-datepicker.css" rel="stylesheet">




    <style>
        .fas {
            padding-top: 7px;
            padding-bottom: 7px;
            font-size: 35px;
            color: rgb(147, 168, 185) !important;
        }

        .mybt{
            width: 30px;
        }

        path {
            fill:chocolate;
        }


        input:focus {
            outline: none;
        }

        .imps{
            border-radius: 9px;
        }

        .myblocks{
            display: inline-flex;
            margin-left: 4%;
            margin-bottom: 2.5%;
        }

        .badge-dark{
            padding: 6px;
        }

        .col-form-label{
            text-align: right;
        }


    </style>
</head>
<body style="background: #fff; font-family: 'Nunito', sans-serif;">

<div class="wrapper d-flex align-items-stretch">
    <?php
    include "services/sidebar.php";
    ?>
    <!-- Page Content  -->
    <div id="content" class="p-md-12">

        <?php
        include "services/topbar.php";
        ?>




        <!--start ForBlocks-->
        <!--        <div id="forBlocks" style="margin: 25px 20px; width: 60%;">-->
        <div id="forBlocks" style="margin-left: 5px; margin-top: 25px; width: 60%;">

            <!--
                       <button style="margin-left: 7%;margin-bottom: 20px; font-size: 18px; border: #fff; background: #fff; color: #343752; margin-right: 35px;" href="dashlistaccounts">
                           <a style="font-size: 18px; color: #000; margin-right: 7px;" href="dashlistaccounts">
                               <span class="fa fa-users" style="color: #343752; font-size: 20px;"> </span>
                               <b style="text-decoration: underline;">List Accounts</b>
                           </a>
                       </button>


                       <button style="margin-bottom: 20px; font-size: 18px; border: #fff; background: #fff; color: #343752; margin-right: 35px;" href="dashcreateaccount">
                           <a style="font-size: 18px; color: #000; margin-right: 7px;" href="dashcreateaccount">
                               <span class="fa fa-user-plus" style="color: #343752; font-size: 20px;"> </span>
                               <b style="text-decoration: underline;">Create Account</b>
                           </a>
                       </button>


                       <button style="margin-bottom: 20px; font-size: 18px; border: #fff; background: #fff; color: #343752; margin-right: 35px;" href="uploadusers">
                           <a style="font-size: 18px; color: #000; margin-right: 7px;" href="uploadusers">
                               <span class="fa fa-user-plus" style="color: #343752; font-size: 20px;"> </span>
                               <b style="text-decoration: underline;">Upload Users</b>
                           </a>
                       </button>
                       -->


            <!--            <form method="post" id="createUserForm" class="needs-validation" novalidate>-->
            <form id="createcashbook" autocomplete="off" method="POST" class="needs-validation" novalidate >
                <!-- Start Spinner -->
                <div class="col-xs-12 app-loader" style="display: none; position: fixed; top: 0; bottom: 0; width: 100%; height: 100%;
                left: 0; text-align: center; z-index: 3; padding-top: 15em;">
                    <div style="background-color: rgba(0,0,0,0.7); display: block; width: 50%; margin-left: 25%; margin-right: 25%">
                        <i class="fa fa-cog fa-spin" style="font-size: 8em; color: #ffffff"></i>
                        <div class="app-loader-message" style="color: #ffffff;"></div>
                    </div>
                </div>
                <!-- End Spinner -->


                <h3 style="margin-left: 7%;">Add Budget Activity</h3>


                <div class="form-group row" style="margin-bottom: 30px;">
                    <label class="col-sm-3 col-form-label" for="budgetname">Budget Name<small style="color:red;">*</small></label>
                    <div class="col-sm-9">
                        <input type="text" class="form-control" id="budgetname" name="budgetname" style="text-transform: uppercase;"
                               value="<?php echo $row[0]; ?>"   data-required-error="Enter the budget name" required readonly>

                        <div class="invalid-feedback">Please select a budget item  </div>
                    </div>
                </div>


                <div class="form-group row" style="margin-bottom: 30px;">
                    <label class="col-sm-3 col-form-label" for="costelement">Cost Element<small style="color:red;">*</small></label>
                    <div class="col-sm-9">
                        <input type="text" class="form-control" id="costelement" name="costelement" style="text-transform: uppercase;"
                                 data-required-error="Enter the cost item description" required >

                        <div class="invalid-feedback">Please provide a cost item description  </div>
                    </div>
                </div>


                <div class="form-group row" style="margin-bottom: 30px;">
                    <label class="col-sm-3 col-form-label" for="economic">Economic Segment<small style="color:red;">*</small></label>
                    <div class="col-sm-9">
                        <select style="text-transform: uppercase !important;" data-required-error="Select an economic segment" class="form-control" name="economic" id="economic" required>
                            <option value="" disabled selected hidden>Select Economic Segment</option>
                            <?php
                            while($rows =  mysqli_fetch_array($resulteco)){
                                echo "<option style=\"text-transform : uppercase\" value=\"$rows[0]\">$rows[0]</option>";
                            }
                            ?>
                        </select>
                        <div class="invalid-feedback">Please select economic segment </div>
                    </div>
                </div>


                <div class="form-group row" style="margin-bottom: 30px;">
                    <label class="col-sm-3 col-form-label" for="admin">Administrative Segment<small style="color:red;">*</small></label>
                    <div class="col-sm-9">
                        <select style="text-transform: uppercase !important;" data-required-error="Select an administrative sector" class="form-control" name="admin" id="admin" required>
                            <option value="" disabled selected hidden>Select Administrative Segment</option>
                            <?php
                            while($rowsadm =  mysqli_fetch_array($resultadm)){
                                echo "<option style=\"text-transform : uppercase\" value=\"$rowsadm[0]\">$rowsadm[0]</option>";
                            }
                            ?>
                        </select>
                        <div class="invalid-feedback">Please select an administrative segment </div>
                    </div>
                </div>


                <div class="form-group row" style="margin-bottom: 30px;">
                    <label class="col-sm-3 col-form-label" for="fund">Fund Segment<small style="color:red;">*</small></label>
                    <div class="col-sm-9">
                        <select style="text-transform: uppercase !important;" data-required-error="Select a fund segment" class="form-control" name="fund" id="fund" required>
                            <option value="" disabled selected hidden>Select Fund Segment</option>
                            <?php
                            while($rowsfund =  mysqli_fetch_array($resultfund)){
                                echo "<option style=\"text-transform : uppercase\" value=\"$rowsfund[0]\">$rowsfund[0]</option>";
                            }
                            ?>
                        </select>
                        <div class="invalid-feedback">Please select an fund segment </div>
                    </div>
                </div>


                <div class="form-group row" style="margin-bottom: 30px;">
                    <label class="col-sm-3 col-form-label" for="func">Functional Segment<small style="color:red;">*</small></label>
                    <div class="col-sm-9">
                        <select style="text-transform: uppercase !important;" data-required-error="Select a fund segment" class="form-control" name="func" id="func" required>
                            <option value="" disabled selected hidden>Select Functional Segment</option>
                            <?php
                            while($rowsfunc =  mysqli_fetch_array($resultfunc)){
                                echo "<option style=\"text-transform : uppercase\" value=\"$rowsfunc[0]\">$rowsfunc[0]</option>";
                            }
                            ?>
                        </select>
                        <div class="invalid-feedback">Please select a functional segment </div>
                    </div>
                </div>


                <div class="form-group row" style="margin-bottom: 30px;">
                    <label class="col-sm-3 col-form-label" for="pro">Program Segment<small style="color:red;">*</small></label>
                    <div class="col-sm-9">
                        <select style="text-transform: uppercase !important;" data-required-error="Select a fund segment" class="form-control" name="pro" id="pro" required>
                            <option value="" disabled selected hidden>Select Program Segment</option>
                            <?php
                            while($rowspro =  mysqli_fetch_array($resultpro)){
                                echo "<option style=\"text-transform : uppercase\" value=\"$rowspro[0]\">$rowspro[0]</option>";
                            }
                            ?>
                        </select>
                        <div class="invalid-feedback">Please select a Program segment </div>
                    </div>
                </div>






                <div class="form-group row" style="margin-bottom: 30px;">
                    <label for="amount" class="col-sm-3 col-form-label">Cost<small style="color:red;">*</small></label>
                    <div class="col-sm-9">
                        <!--                        <input type="number" onblur="formatCurrency(this)"  class="form-control imps floatNumberField" id="amount" name="amount" placeholder="" required>-->
                        <input type="number" step='0.01' class="form-control floatNumberField" id="amount" name="amount" placeholder="" required>

                        <div class="invalid-feedback"> Enter Cost </div>
                    </div>
                </div>


                <div class="form-group row" style="margin-bottom: 30px;">
                    <label class="col-sm-3 col-form-label" for="location">Location<small style="color:red;">*</small></label>
                    <div class="col-sm-9">
                        <select style="text-transform: uppercase !important;" data-required-error="Select a location" class="form-control" name="location" id="location" required>
                            <option value="" disabled selected hidden>Select A Location</option>
                            <?php
                            while($row22 =  mysqli_fetch_array($resultlga)){
                                echo "<option style=\"text-transform : uppercase\" value=\"$row22[0]\">$row22[0]</option>";
                            }
                            ?>
                        </select>
                        <div class="invalid-feedback">Please select a location </div>
                    </div>
                </div>


                <div class="form-group row" style="margin-bottom: 30px;">
                    <label for="cbdate" class="col-sm-3 col-form-label">Timing of Activity <small style="color:red;">*</small></label>
                    <div class="col-sm-9">
                        <!--                        <input type="date" class="form-control imps" id="cbdate" name="cbdate" placeholder="" required>-->
                        <input type="text" class="form-control mydatepicker" id="cbdate" name="cbdate"
                               placeholder="Start Date" data-required-error="Enter start date of entry to be created" required>

                        <div class="invalid-feedback">Enter timing of Activity </div>
                    </div>
                </div>

                <div class="form-group row" style="margin-bottom: 30px;">
                    <label class="col-sm-3 col-form-label" for="verify"> Activity  Means of Verification <small style="color:red;">*</small></label>
                    <div class="col-sm-9">
                        <input type="text" class="form-control" id="verify" name="verify" style="text-transform: uppercase;"
                               data-required-error="Enter the means of verification" required >

                        <div class="invalid-feedback">Please provide means of verification  </div>
                    </div>
                </div>


                <div class="form-group row" style="margin-bottom: 30px;">
                    <label class="col-sm-3 col-form-label" for="priority">Priority<small style="color:red;">*</small></label>
                    <div class="col-sm-9">
                        <select style="text-transform: uppercase !important;" type="text" class="form-control imps" id="priority" name="priority" required>
                            <option disabled selected  hidden value=""></option>
                            <option value="High">High</option>
                            <option value="Medium">Medium</option>
                            <option value="Low">Low</option>

                        </select>
                        <div class="invalid-feedback">Please select priority </div>
                    </div>
                </div>




                <div style="margin-left: 17%;">

                    <button type="submit" class="btn btn-sm" style="border-radius: 50px; background: #2d73b0; color: #fff; margin-bottom: 2%; box-shadow: 5px 5px 18px 1px #888888;">
                        <i class="fa fa-save"></i> Save
                    </button>


                    <button type="reset" class="btn btn-sm btn-secondary" style="border-radius: 50px; margin-bottom: 2%;"> x Cancel</button>

                </div>



            </form>






        </div>
        <!--end forBlocks-->


    </div>




</div>

<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/popper.js"></script>
<script src="assets/bootstrap/js/bootstrap.min.js"></script>
<script src="assets/js/main.js"></script>
<script src="assets/js/validator.min.js"></script>
<script src="assets/js/bootstrap-datepicker.js"></script>
<script>
    hyperform(window);
</script>



<script type="text/javascript">

    function formatCurrency(amounts){
        // console.log( new Intl.NumberFormat().format($(amounts))) ;
    }
    $(document).ready(function () {
        $(".floatNumberField").change(function() {
            $(this).val(parseFloat($(this).val()).toFixed(2));
            console.log( new Intl.NumberFormat('en-NG').format($(this).val())) ;
            var amount2 = new Intl.NumberFormat('en-NG').format($(this).val());

            // $(this).val() = amount2;
            // Intl.NumberFormat().format( $(this) );
            // console.log(  $(this).val(parseFloat($(this).val()).toFixed(2)).toString()  ) ;
        });
    });
</script>

<script>
    $( ".mydatepicker" ).datepicker({
        format: "dd-M-yyyy"
    });
</script>


<script>
    (function () {
        'use strict';

        // Fetch all the forms we want to apply custom Bootstrap validation styles to
        var forms = document.querySelectorAll('.needs-validation');

        // Loop over them and prevent submission
        Array.prototype.slice.call(forms)
            .forEach(function (form) {
                form.addEventListener('submit', function (event) {
                    if (!form.checkValidity()) {
                        event.preventDefault();
                        event.stopPropagation();
                    }

                    form.classList.add('was-validated')
                }, false)
            })
    })();



    $('#createcashbook').on("submit", function(submitEvent){

        // form was successfully validated
        if(! submitEvent.isDefaultPrevented()) {
            // prevent the form from submitting automatically
            submitEvent.preventDefault();


            // display the app-loader
            $('.app-loader').css("display", "block");
            $('.app-loader-message').html("<div>Adding Budget Activity...</div>" +
                "<div>PLEASE DO NOT CLOSE BROWSER</div>");


            // submit the from via ajax
            var x=$.ajax({
                url: "services/fmaddbudgetactivity", // Url to which the request is send
                type: "POST",             // Type of request to be send, called as method
                data: new FormData($('#createcashbook').get(0)), // Data sent to server, a set of key/value pairs (i.e. form fields and values)
                contentType: false,       // The content type used when sending data to the server.
                dataType:"text",
                timeout: 300000,
                cache: false,             // disable page caching
                processData: false
            });

            x.done(function(myresponse)
            {
                // console.log("this is my",myresponse);
                if(myresponse.includes('success')){
                    console.log(myresponse);
                    $('.app-loader').css("display", "none");
                    Swal.fire({
                        position: 'center',
                        icon: 'success',
                        title: 'Activity Was successfully added',
                        showConfirmButton: false,
                        timer: 2500
                    });

                    setTimeout(function(){
                        location.href = "approvedbudget";
                    }, 2500);


                }

                else{

                    Swal.fire({
                        icon: 'error',
                        title: 'Error Occured',
                        text: 'Please try again later',

                    });

                    $('.app-loader').css("display", "none");
                }

            });


        }
    });


</script>


<script>
    console.log('I got this');
    $('#addDivision').click(function(){
        $('.app-loader').css("display", "block");
        $('.app-loader-message').html("<div>Adding Entry...</div>" +
            "<div>PLEASE DO NOT CLOSE BROWSER</div>");
    });


    $('#manage').click(function(){
        console.log("manage button clicked");
    });
</script>


<script>
    $('#account').change(function(){
        var selectedVal =  $('#account option:selected').text();
        console.log('selected value is ', selectedVal);
        // console.log('selected value is ',   $('#account option:selected').text());

        $('.app-loader').css("display", "block");
        $('.app-loader-message').html("<div>Fetching Code Descriptions...</div>" +
            "<div>PLEASE DO NOT CLOSE BROWSER</div>");

        var gets = $.ajax({
            url: "services/fmgetaccountcodes?acc=" + selectedVal, // Url to which the request is send
            type: "GET",             // Type of request to be send, called as method
            // data: , // Data sent to server, a set of key/value pairs (i.e. form fields and values)
            // data: new FormData($('#createaccountform').get(0)), // Data sent to server, a set of key/value pairs (i.e. form fields and values)
            contentType: false,       // The content type used when sending data to the server.
            dataType:"text",
            timeout: 300000,
            cache: false,             // disable page caching
            processData: false
        });

        gets.done(function(serverResponse)
        {
            $('.app-loader').css("display", "none");
            console.log(serverResponse);
            var servervalue=serverResponse.trim();
            $('#accountdescr').html('');
            $('#accountdescr').append('<option value="" selected hidden disabled>Select A Description</option>');
            $('#accountdescr').append(servervalue);

        });

        gets.fail(function(){

        });


    });

</script>

</body>
</html>


