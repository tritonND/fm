<?php
session_start();
include "services/connect.php";

if(!isset($_SESSION["user"])){
    header( "Location: index");
}
else{

}

$organization = $_SESSION['organization'];
$ministry = $_SESSION['ministry'];
$sector = $_SESSION['sector'];
$states = $_SESSION['states'];


$budgetid = $_GET['id'];

$myqry = "select budgetname, duration from fm_budget where ID = '$budgetid'";
$result3 = mysqli_query($conn, $myqry);
$row =  mysqli_fetch_array($result3);


$myqry1 = "select budgetname from fm_budgetactivity where ID = '$budgetid'";
$result31 = mysqli_query($conn, $myqry1);
$rowa =  mysqli_fetch_array($result31);


?>

<!doctype html>
<html lang="en">
<head>
    <title>Dashboard</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">

    <link rel="stylesheet" href="assets/fontawesome/css/all.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

    <link rel="stylesheet" href="assets/bootstrap/css/style.css">
    <link rel="stylesheet" href="assets/css/hyperform.min.css">
    <script src="assets/js/polyfill.min.js"></script>
    <script src="assets/js/hyperform.min.js"></script>

    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300&display=swap" rel="stylesheet">



    <script src="assets/js/sweetalert2.all.min.js"></script>
    <link href="assets/css/sweetalert2.min.css" rel="stylesheet">
    <link href="assets/css/bootstrap-datepicker.css" rel="stylesheet">
    <link href="assets/css/datatables.min.css" rel="stylesheet">




    <style>
        .fas {
            padding-top: 7px;
            padding-bottom: 7px;
            font-size: 35px;
            color: rgb(147, 168, 185) !important;
        }

        .mybt{
            width: 30px;
        }

        path {
            fill:chocolate;
        }


        input:focus {
            outline: none;
        }

        .imps{
            border-radius: 9px;
        }

        .myblocks{
            display: inline-flex;
            margin-left: 4%;
            margin-bottom: 2.5%;
        }

        .badge-dark{
            padding: 6px;
        }

        .col-form-label{
            text-align: right;
        }


    </style>
</head>
<body style="background: #fff; font-family: 'Nunito', sans-serif;">

<div class="wrapper d-flex align-items-stretch">
    <?php
    include "services/sidebar.php";
    ?>
    <!-- Page Content  -->
    <div id="content" class="p-md-12">

        <?php
        include "services/topbar.php";
        ?>




        <!--start ForBlocks-->
        <!--        <div id="forBlocks" style="margin: 25px 20px; width: 60%;">-->
        <div id="forBlocks" style="margin-left: 5%; margin-top: 25px; width: 90%;">

            <a style="margin-left: 0%; margin-bottom:1%" class="btn btn-sm btn-primary" href="approvedbudget">Approved Budget</a>


            <h5 style="text-transform: uppercase">Budget Name: <?php echo $row[0]; ?></h5>
            <h5>Budget Duration: <?php echo $row[1]; ?> Months</h5>

            <h5 style="text-transform: uppercase">Budget Funders </h5>
            <table id="myTable" class="table table-condensed table-striped table-bordered table-hover" >
                <thead class="bg-dark" style="color: #ffffff">

                <tr>
                    <th>Funder</th>
                    <th>Duration</th>
                    <th>Amount</th>
                    <th>Date Added</th>
                </tr>
                </thead>
                <?php

                $query1 = "SELECT * FROM fm_projectfunding where budgetname = '$row[0]' ORDER BY datecreated desc";

                $result = mysqli_query($conn, $query1) or die('Query fail: ' . mysqli_error($conn));

                ?>
                <tbody>
                <?php while ($row1 = mysqli_fetch_array($result)) { ?>
                    <tr>

                        <td><?php echo  "<p style='text-transform: uppercase;'>". $row1[2] ; ?></td>
                        <td><?php echo  "<p style='text-transform: uppercase;'>". $row1[3]. " - " . $row1[4] ; ?></td>
                        <td><?php echo  "<p style='text-transform: uppercase;'>". number_format($row1[5],2) ; ?></td>
                        <td><?php echo  "<p style='text-transform: uppercase;'>". $row1[7] ; ?></td>

                    </tr>
                <?php } ?>
                </tbody>
            </table>



            <h5 style="text-transform: uppercase; margin-top: 5%">Budget Activities</h5>
            <table id="myTable1" class="table table-condensed table-striped table-bordered table-hover " style="margin-top: 3%">
                <thead class="bg-dark" style="color: #ffffff">

                <tr>
                    <th>Budget Activity</th>
                    <th>Cost Element</th>
                    <th>Economic Segment</th>
                    <th>Administrative Segment</th>
                    <th>Fund Segment</th>
                    <th>Functional Segment</th>
                    <th>Program Segment</th>
                    <th>Amount</th>
                    <th>Location</th>
                </tr>
                </thead>
                <?php

                $query2 = "SELECT * FROM fm_budgetactivity where budget = '$row[0]' ORDER BY datecreated desc";

                $result2 = mysqli_query($conn, $query2) or die('Query fail: ' . mysqli_error($conn));

                ?>
                <tbody>
                <?php while ($row2 = mysqli_fetch_array($result2)) { ?>
                    <tr>

                        <td><?php echo  "<p style='text-transform: uppercase;'>". $row2[2] ; ?></td>
                        <td><?php echo  "<p style='text-transform: uppercase;'>". $row2[3] ; ?></td>
                        <td><?php echo  "<p style='text-transform: uppercase;'>". $row2[4] ; ?></td>
                        <td><?php echo  "<p style='text-transform: uppercase;'>". $row2[5] ; ?></td>
                        <td><?php echo  "<p style='text-transform: uppercase;'>". $row2[6] ; ?></td>
                        <td><?php echo  "<p style='text-transform: uppercase;'>". $row2[7] ; ?></td>
                        <td><?php echo  "<p style='text-transform: uppercase;'>". $row2[8] ; ?></td>
                        <td><?php echo  "<p style='text-transform: uppercase;'>". number_format($row2[9],2) ; ?></td>
                        <td><?php echo  "<p style='text-transform: uppercase;'>". $row2[10] ; ?></td>

                    </tr>
                <?php } ?>
                </tbody>
            </table>




        </div>
        <!--end forBlocks-->


    </div>




</div>

<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/popper.js"></script>
<script src="assets/bootstrap/js/bootstrap.min.js"></script>
<script src="assets/js/main.js"></script>
<script src="assets/js/validator.min.js"></script>
<script src="assets/js/bootstrap-datepicker.js"></script>
<script src="assets/js/datatables.min.js"></script>
<script>
    hyperform(window);
</script>



<script type="text/javascript">

    function formatCurrency(amounts){
        // console.log( new Intl.NumberFormat().format($(amounts))) ;
    }
    $(document).ready(function () {
        $(".floatNumberField").change(function() {
            $(this).val(parseFloat($(this).val()).toFixed(2));
            console.log( new Intl.NumberFormat('en-NG').format($(this).val())) ;
            var amount2 = new Intl.NumberFormat('en-NG').format($(this).val());

            // $(this).val() = amount2;
            // Intl.NumberFormat().format( $(this) );
            // console.log(  $(this).val(parseFloat($(this).val()).toFixed(2)).toString()  ) ;
        });
    });
</script>


<script>
    $('#myTable').DataTable(
        {
            dom: 'Bfrtip',
            buttons: ['copy', 'csv', 'excel', 'pdf', 'print']
        }
    );


    $('#myTable1').DataTable(
        {
            dom: 'Bfrtip',
            buttons: ['copy', 'csv', 'excel', 'pdf', 'print']
        }
    );

</script>



</body>
</html>


