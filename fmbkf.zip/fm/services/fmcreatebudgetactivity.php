<?php

include "connect.php";
session_start();


$budgetname = trim(strip_tags($_POST['budgetname']));
$activityname = trim(strip_tags($_POST['activityname']));

$createdby = $_SESSION["user"];
$organization = $_SESSION['organization'];
$ministry = $_SESSION['ministry'];
$sector = $_SESSION['sector'];
$states = $_SESSION['states'];


$mysql = "INSERT into fm_budgetactivitytable (budgetname, activityname, organization, sector, ministry, state, createdby, datecreated) VALUES 
                        ('$budgetname', '$activityname', '$organization', '$sector', '$ministry', '$states', '$createdby', now()) ";


$result = mysqli_query($conn, $mysql);

if(mysqli_affected_rows($conn) >0){
    echo "success";
    audit_trail("Budget activityname Created - ". $activityname. "budget name: ". $budgetname );
}
else {
    echo "fail";
}



?>

