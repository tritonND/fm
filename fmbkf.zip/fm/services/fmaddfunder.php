<?php

include "connect.php";
session_start();


$budgetname = trim(strip_tags($_POST['budgetname']));
$funder = trim(strip_tags($_POST['budgetfunder']));
$start = trim(strip_tags($_POST['cbdate']));
$finish = trim(strip_tags($_POST['cbdate1']));
$amount = trim(strip_tags($_POST['amount']));

$createdby = $_SESSION["user"];
$organization = $_SESSION['organization'];
$ministry = $_SESSION['ministry'];
$sector = $_SESSION['sector'];
$states = $_SESSION['states'];



$mysql = "INSERT into fm_projectfunding (budgetname, funder, start_date, end_date, amount, organization, sector, ministry, state, createdby, datecreated) VALUES 
                        ('$budgetname', '$funder', '$start' , '$finish' , '$amount' ,'$organization', '$sector', '$ministry', '$states', '$createdby', now()) ";


$result = mysqli_query($conn, $mysql);

if(mysqli_affected_rows($conn) >0){
    echo "success";
    audit_trail("Budget Funder Created - ". $budgetname . " - ". $funder);
}
else {
    echo "fail";
}



?>

