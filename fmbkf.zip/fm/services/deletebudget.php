<?php

include "connect.php";
session_start();
$id = $_GET['id'];

$mysql = "DELETE from fm_budget where ID = '$id' ";

$result = mysqli_query($conn, $mysql);

if(mysqli_affected_rows($conn) >0){
    echo "success";
    audit_trail("Budget entry deleted for ID". $id);
}
else {
    echo "fail";
}

?>

