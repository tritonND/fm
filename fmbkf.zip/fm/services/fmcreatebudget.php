<?php

include "connect.php";
session_start();


$budgetname = trim(strip_tags($_POST['budgetname']));
$duration = trim(strip_tags($_POST['duration']));

$createdby = $_SESSION["user"];
$organization = $_SESSION['organization'];
$ministry = $_SESSION['ministry'];
$sector = $_SESSION['sector'];
$states = $_SESSION['states'];



$mysql = "INSERT into fm_budget (budgetname, duration,organization, sector, ministry, state, createdby, datecreated) VALUES 
                        ('$budgetname', '$duration','$organization', '$sector', '$ministry', '$states', '$createdby', now()) ";


//echo  $mysql;
//echo $accountname." ". $createdby . " ". $mysql;
$result = mysqli_query($conn, $mysql);

if(mysqli_affected_rows($conn) >0){
    echo "success";
    audit_trail("Budget Created - ". $budgetname . " - with duration of ". $duration . " months");
}
else {
    echo "fail";
}



?>


