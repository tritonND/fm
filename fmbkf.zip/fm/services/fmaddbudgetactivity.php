<?php

include "connect.php";
session_start();


$budget = trim(strip_tags($_POST['budget']));
$budgetname = trim(strip_tags($_POST['budgetname']));
$costelement = trim(strip_tags($_POST['costelement']));
$economic = trim(strip_tags($_POST['economic']));
$admin = trim(strip_tags($_POST['admin']));
$fund = trim(strip_tags($_POST['fund']));
$func = trim(strip_tags($_POST['func']));
$pro = trim(strip_tags($_POST['pro']));

$amount = trim(strip_tags($_POST['amount']));
$location = trim(strip_tags($_POST['location']));

$priority = trim(strip_tags($_POST['priority']));
$verify = trim(strip_tags($_POST['verify']));
$cbdate = trim(strip_tags($_POST['cbdate']));



$createdby = $_SESSION["user"];
$organization = $_SESSION['organization'];
$ministry = $_SESSION['ministry'];
$sector = $_SESSION['sector'];
$states = $_SESSION['states'];



$mysql = "INSERT into fm_budgetactivity(budget, budgetname, costelement, economic, admin, fund, func, pro, amount, location, organization, sector, ministry, state, createdby, datecreated, priority, verify, duration) VALUES 
                        ('$budget', '$budgetname', '$costelement', '$economic' , '$admin', '$fund' , '$func' , '$pro' , $amount , '$location','$organization', '$sector', '$ministry', '$states', '$createdby', now(), '$priority', '$verify', '$cbdate') ";

//echo $mysql;
$result = mysqli_query($conn, $mysql);

if(mysqli_affected_rows($conn) >0){
    echo "success";
    audit_trail("Budget activity Created - ". $budgetname . " - ". $costelement);
}
else {
    echo "fail";
    echo mysqli_error($conn);
}



?>

