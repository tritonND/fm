<?php

include "connect.php";
session_start();
$id = $_GET['id'];

$mysql = "DELETE from fm_cashbook where ID = '$id' ";

$result = mysqli_query($conn, $mysql);

if(mysqli_affected_rows($conn) >0){
    echo "success";
    audit_trail("Cashbook entry deleted for ID". $id);
}
else {
    echo "fail";
}

?>

