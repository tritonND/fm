<?php

include "connect.php";
session_start();
$id = $_GET['id'];

$mysql = "UPDATE categorytable set status = 1 where ID = '$id' ";

$result = mysqli_query($conn, $mysql);

if(mysqli_affected_rows($conn) >0){
    echo "success";
    audit_trail("Category Approved with ID ". $id);
}
else {
    echo "fail";
}

?>

